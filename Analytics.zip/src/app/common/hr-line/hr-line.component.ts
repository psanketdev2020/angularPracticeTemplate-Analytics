import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-line',
  templateUrl: './hr-line.component.html',
  styleUrls: ['./hr-line.component.css']
})
export class HrLineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
